				WEBSITE S1 KIMIA UNS
	Website Kimia Uns ini sebenarnya telah dirancang untuk bisa digunakan secara offline. Hanya saja karena terdapat fitur tambahan berupa Map yang harus menggunakan koneksi internet. Maka untuk dapat melihat tampilan web dengan menyeluruh harus menggunakan koneksi internet.
Untuk cara penggunaan ataupun mengetahui  fitur apa saja yang terdapat pada website S1 Kimia UNS. Berikut adalah penjelasanya.
1. Pada semua halaman website terdapat bagian navbar dan footer
	a. Navabar
	  • Apabila di klik bagian logo kimia maka akan muncul notif
	  • Apabila wesite telah di scorl kebawah, kemudian ingin kebali ke atas bisa di klik navbar Home
	  • Untuk Profil apabila diklik akan terdapat macam macam menu di profil, demikian juga untuk Informasi, Publikasi.
	  • Sedangkan untuk kontak jika di klik akan langsung terhubung dengan halaman kontak
	b. Footer
	  • Pada bagian footer terdapat  menu seperti pada navbar , apabila menu tersebut misal seperti profil, informasi dan publikasi diklik maka akan muncul effect toggle ke bawah
	  • Tambah juga untuk media social yang nantinya akan terhubung ke media social himpunan
2. Bagian  Halaman Utama
	a. Slide Image
	   Pada bagian Slide Image pertama terdapat tombol botton berupa sejarah , Apabila di klik maka akan langsung menuju ke halaman sejarah
	b. Portofolio
	   Pada bagian Portofolio berisi penelitian berupa wawancara yang disampaikan melalui video youtube. Klik bagian circle image atau next maka akan menuju ke halaman konten berupa   	   portofolio
	c. Sidebar
	   Pada bagian sidebar terdapat popular post, agenda, archives dan check tag. Apabila di klik maka akan muncul efek toggle  kebawah dan apabila diklik lagi akan kembali seperti 	   semula. Untuk bagian check tag bisa kita bisa mencari tagar yang terdapat pada website. Hanya saja saya belum menggantinya sesuai dengan website. Bisa dicoba di ketik “ java” 	   akan muncul tagar java

	